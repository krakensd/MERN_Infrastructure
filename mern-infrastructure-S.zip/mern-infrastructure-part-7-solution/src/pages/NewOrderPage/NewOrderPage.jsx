export default function NewOrderPage() {
    return (
        <h1>NewOrderPage</h1>
    );
}