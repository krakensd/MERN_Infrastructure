import './Logo.css';

export default function Logo() {
  return (
    <div className="Logo">
      <div>SEI</div>
      <div>CAFE</div>
    </div>
  );
}