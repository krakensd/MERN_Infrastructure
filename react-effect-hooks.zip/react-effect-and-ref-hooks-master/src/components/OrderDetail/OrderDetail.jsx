import './OrderDetail.css';

export default function OrderDetail() {
  return (
    <div className="OrderDetail">
      <div className="section-heading">
        OrderDetail Component
      </div>
    </div>
  );
}